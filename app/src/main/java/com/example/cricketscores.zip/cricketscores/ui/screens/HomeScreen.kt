package com.example.cricketscores.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AcUnit
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.FiberManualRecord
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.SelfImprovement
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.wear.compose.foundation.lazy.TransformingLazyColumn
import androidx.wear.compose.foundation.lazy.TransformingLazyColumnState
import androidx.wear.compose.foundation.lazy.items
import androidx.wear.compose.material3.AppCard
import androidx.wear.compose.material3.Button
import androidx.wear.compose.material3.Icon
import androidx.wear.compose.material3.ListHeader
import androidx.wear.compose.material3.ListSubHeader
import androidx.wear.compose.material3.MaterialTheme
import androidx.wear.compose.material3.SurfaceTransformation
import androidx.wear.compose.material3.Text
import androidx.wear.compose.material3.lazy.TransformationSpec
import androidx.wear.compose.material3.lazy.transformedHeight
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.material3.pulltorefresh.rememberPullToRefreshState
import com.example.cricketscores.R
import com.example.cricketscores.model.LiveMatch
import com.example.cricketscores.model.MatchDetails
import com.example.cricketscores.model.RecentMatch
import com.example.cricketscores.model.ScheduleMatch
import com.example.cricketscores.ui.theme.WearAppTheme
import com.example.cricketscores.utils.TeamIconUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    cricketUiState: CricketUiState,
    retryAction: () -> Unit,
    listState: TransformingLazyColumnState,
    contentPadding: PaddingValues,
    transformationSpec : TransformationSpec,
    modifier: Modifier = Modifier,
    onOpenDetails: (String) -> Unit
) {
    when (cricketUiState) {
        is CricketUiState.Loading -> LoadingScreen(modifier = modifier.fillMaxSize())
        is CricketUiState.Success -> {
            val pullToRefreshState = rememberPullToRefreshState()
            var isRefreshing by remember { mutableStateOf(false) }

            LaunchedEffect(cricketUiState) {
                if (isRefreshing) isRefreshing = false
            }

            PullToRefreshBox(
                isRefreshing = isRefreshing,
                onRefresh = {
                    isRefreshing = true
                    retryAction()
                },
                state = pullToRefreshState
            ) {
                MatchesGridScreen(
                    cricketUiState.liveMatches,
                    cricketUiState.recentMatches,
                    cricketUiState.schedule,
                    listState = listState,
                    contentPadding = contentPadding,
                    transformationSpec = transformationSpec,
                    onOpenDetails = onOpenDetails,
                    modifier = Modifier
                )
            }
        }
        is CricketUiState.Error -> ErrorScreen(retryAction, modifier = modifier.fillMaxSize())
    }
}

/**
 * The home screen displaying match grid.
 */
@Composable
fun MatchesGridScreen(
    matches: List<LiveMatch>,
    recentMatches: List<RecentMatch>,
    schedule: List<ScheduleMatch>,
    listState: TransformingLazyColumnState,
    contentPadding: PaddingValues,
    transformationSpec : TransformationSpec,
    onOpenDetails: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    TransformingLazyColumn(
        modifier = modifier,
        state = listState,
        contentPadding = contentPadding,
    ){
        item{
            TextAppHeader(
                modifier =
                    Modifier.fillMaxWidth().transformedHeight(this, transformationSpec),
                transformation = SurfaceTransformation(transformationSpec),
            )
        }
        item{
            TextSubHeader(
                modifier =
                    Modifier.fillMaxWidth().transformedHeight(this, transformationSpec),
                transformation = SurfaceTransformation(transformationSpec),
                icon = Icons.Rounded.FiberManualRecord,
                iconColor = Color.Red, // 🔴 red for live
                labelText = "Live Matches"
            )
        }
        items(items=matches){ match ->
            MatchCard(
                match = match,
                modifier =
                    Modifier.fillMaxWidth().transformedHeight(this, transformationSpec),
                transformation = SurfaceTransformation(transformationSpec),
                onClick = { onOpenDetails(match.matchId) }
            )
        }
        item{
            TextSubHeader(
                modifier =
                    Modifier.fillMaxWidth().transformedHeight(this, transformationSpec),
                transformation = SurfaceTransformation(transformationSpec),
                icon = Icons.Rounded.CheckCircle,
                iconColor = Color.Gray,
                labelText = "Recent Matches"
            )
        }
        items(items=recentMatches){ match ->
            RecentMatchCard(
                match = match,
                modifier =
                    Modifier.fillMaxWidth().transformedHeight(this, transformationSpec),
                transformation = SurfaceTransformation(transformationSpec),
                onClick = { onOpenDetails(match.matchId) }
            )
        }
        item{
            TextSubHeader(
                modifier =
                    Modifier.fillMaxWidth().transformedHeight(this, transformationSpec),
                transformation = SurfaceTransformation(transformationSpec),
                icon = Icons.Rounded.Schedule,
                iconColor = Color.Blue,
                labelText = "Upcoming Matches"
            )
        }
        items(items=schedule){ s ->
            ScheduleCard(
                match = s,
                modifier =
                    Modifier.fillMaxWidth().transformedHeight(this, transformationSpec),
                transformation = SurfaceTransformation(transformationSpec),
                onClick = { }
            )
        }
    }
}
@Composable
fun ScheduleCard(
    match: ScheduleMatch,
    modifier: Modifier = Modifier,
    transformation: SurfaceTransformation,
    onClick: () -> Unit,
) {
    AppCard(
        onClick = {},
        appName = {  }, // optional header
        time = { Text(match.date, style = MaterialTheme.typography.bodyExtraSmall, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f) ) },        // optional time (can remove if not needed)
        title = { },
        modifier = modifier,
        transformation = transformation
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Team 1
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    Image(
                        painter = painterResource(TeamIconUtils.getTeamFlagIcon(match.team1)),
                        contentDescription = "${match.team1} flag",
                        modifier = Modifier.size(18.dp)
                    )
                    Text(match.team1, style = MaterialTheme.typography.bodySmall)
                }

                // VS text styling
                Text(
                    "VS",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                )

                // Team 2
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    Image(
                        painter = painterResource(TeamIconUtils.getTeamFlagIcon(match.team2)),
                        contentDescription = "${match.team2} flag",
                        modifier = Modifier.size(18.dp)
                    )
                    Text(match.team2, style = MaterialTheme.typography.bodySmall)
                }
            }

            // Match info styling
            Text(
                match.details,
                style = MaterialTheme.typography.bodySmall.copy(
                    fontStyle = FontStyle.Italic,
                    color = Color.Gray
                ),
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
        }

    }
}
@Composable
fun RecentMatchCard(
    match: RecentMatch,
    modifier: Modifier = Modifier,
    transformation: SurfaceTransformation,
    onClick: () -> Unit,
) {
    AppCard(
        onClick = onClick,
        appName = { Text(match.matchSummary, style = MaterialTheme.typography.bodyExtraSmall ) },
        time = { Text("Recent", style = MaterialTheme.typography.bodyExtraSmall, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f) ) },
        title = { },
        modifier = modifier,
        transformation = transformation
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Team 1 row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painter = painterResource(TeamIconUtils.getTeamFlagIcon(match.team1.team)),
                        contentDescription = "${match.team1.team} flag",
                        modifier = Modifier.size(18.dp)
                    )
                    Text(match.team1.team, style = MaterialTheme.typography.bodySmall)
                }
                Text(match.team1.score, style = MaterialTheme.typography.bodySmall)
            }

            // Team 2 row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painter = painterResource(TeamIconUtils.getTeamFlagIcon(match.team2.team)),
                        contentDescription = "${match.team2.team} flag",
                        modifier = Modifier.size(18.dp)
                    )
                    Text(match.team2.team, style = MaterialTheme.typography.bodySmall)
                }
                Text(match.team2.score, style = MaterialTheme.typography.bodySmall)
            }

            // Result line
            Text(match.result, style = MaterialTheme.typography.bodyExtraSmall)
        }
    }
}

@Composable
fun TextAppHeader(modifier: Modifier = Modifier, transformation: SurfaceTransformation) {
    ListHeader(
        modifier = modifier,
        transformation = transformation,
    ) {
        Text(
            modifier = modifier,
            textAlign = TextAlign.Center,
            text = "CricScores",
        )
    }
}

@Composable
fun TextSubHeader(modifier: Modifier = Modifier,
                   transformation: SurfaceTransformation,
                   icon: ImageVector,       // pass the icon
                   iconColor: Color,        // pass the color
                   labelText: String        // make text configurable too
) {
    ListSubHeader(
        modifier = modifier,
        transformation = transformation,
        icon = {
            Icon(
                imageVector = icon,
                contentDescription = "triggers open message action",
                modifier = Modifier
                    .size(16.dp)
                    .clip(CircleShape)
                    .background(iconColor)
                    .padding(3.dp)  // gives breathing room inside the circle
            )
        },
        label = {
            Text(
                modifier = modifier,
                textAlign = TextAlign.Center,
                text = labelText,
            )
        },
    )
}
/**
 * The home screen displaying the loading message.
 */
@Composable
fun LoadingScreen(modifier: Modifier = Modifier) {
    Image(
        modifier = modifier.size(200.dp),
        painter = painterResource(R.drawable.loading_img),
        contentDescription = stringResource(R.string.loading)
    )
}

/**
 * The home screen displaying error message with re-attempt button.
 */
@Composable
fun ErrorScreen(retryAction: () -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            painter = painterResource(id = R.drawable.ic_connection_error), contentDescription = ""
        )
        Text(text = stringResource(R.string.loading_failed), modifier = Modifier.padding(16.dp))
        Button(onClick = retryAction) {
            Text(stringResource(R.string.retry))
        }
    }
}

// TODO: Create a Chip Composable
@Composable
fun MatchCard(
    match: LiveMatch,
    modifier: Modifier = Modifier,
    transformation: SurfaceTransformation,
    onClick: () -> Unit,
) {
    AppCard(
        onClick = onClick,
        appName = { Text(match.liveMatchSummary, style = MaterialTheme.typography.bodyExtraSmall ) }, // optional header
        time = { Text("Live", style = MaterialTheme.typography.bodyExtraSmall, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f) ) },        // optional time (can remove if not needed)
        title = { },
        modifier = modifier,
        transformation = transformation
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Team 1 row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painter = painterResource(TeamIconUtils.getTeamFlagIcon(match.team1.team)),
                        contentDescription = "${match.team1.team} flag",
                        modifier = Modifier.size(18.dp)
                    )
                    Text(match.team1.team, style = MaterialTheme.typography.bodySmall)
                }
                Text(match.team1.score, style = MaterialTheme.typography.bodySmall)
            }

            // Team 2 row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painter = painterResource(TeamIconUtils.getTeamFlagIcon(match.team2.team)),
                        contentDescription = "${match.team2.team} flag",
                        modifier = Modifier.size(18.dp)
                    )
                    Text(match.team2.team, style = MaterialTheme.typography.bodySmall)
                }
                Text(match.team2.score, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
fun MatchDetailScreen(currentMatchDetails: CricketViewModel.currentMatchDetails, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(8.dp)
    ) {
        Text(text = details.title ?: "Match", maxLines = 2, overflow = TextOverflow.Ellipsis)
        Text(text = details.title ?: "Match", maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}