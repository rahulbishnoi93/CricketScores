/*
 * Copyright (C) 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.example.cricketscores.ui.screens

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.cricketscores.CricketApplication
import com.example.cricketscores.data.CricketMatchesRepository
import com.example.cricketscores.model.LiveMatch
import com.example.cricketscores.model.MatchDetails
import com.example.cricketscores.model.RecentMatch
import com.example.cricketscores.model.ScheduleMatch
import kotlinx.coroutines.launch
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import retrofit2.HttpException
import java.io.IOException

/**
 * UI state for the Home screen
 */
sealed interface CricketUiState {
    data class Success(
        val liveMatches: List<LiveMatch>,
        val recentMatches: List<RecentMatch>,
        val schedule: List<ScheduleMatch>,
    ) : CricketUiState
    object Error : CricketUiState
    object Loading : CricketUiState
}

class CricketViewModel(private val cricketMatchesRepository: CricketMatchesRepository) : ViewModel() {
    /** The mutable State that stores the status of the most recent request */
    var cricketUiState: CricketUiState by mutableStateOf(CricketUiState.Loading)
        private set

    var currentMatchDetails: MatchDetails? by mutableStateOf(null)
        private set

    /**
     * Call getMarsPhotos() on init so we can display status immediately.
     */
    init { loadHomeData() }

    /**
     * Gets Mars photos information from the Mars API Retrofit service and updates the
     * [MarsPhoto] [List] [MutableList].
     */
    fun loadHomeData() {
        viewModelScope.launch {
            cricketUiState = CricketUiState.Loading
            cricketUiState = try {
                val liveDeferred = async { cricketMatchesRepository.getLiveMatches() }
                val recentDeferred = async { cricketMatchesRepository.getRecentMatches() }
                val scheduleDeferred = async { cricketMatchesRepository.getSchedule() }
                val (live, recent, schedule) = awaitAll(liveDeferred, recentDeferred, scheduleDeferred)
                CricketUiState.Success(
                    liveMatches = live as List<LiveMatch>,
                    recentMatches = recent as List<RecentMatch>,
                    schedule = schedule as List<ScheduleMatch>,
                )
            } catch (e: IOException) {
                CricketUiState.Error
            } catch (e: HttpException) {
                CricketUiState.Error
            }
        }
    }

    fun getMatchDetails(id: String) {
        viewModelScope.launch {
            try {
                currentMatchDetails = cricketMatchesRepository.getMatchDetails(id)
            } catch (e: IOException) {
                currentMatchDetails = null
            } catch (e: HttpException) {
                currentMatchDetails = null
            }
        }
    }

    fun clearMatchDetails() {
        currentMatchDetails = null
    }

    /**
     * Factory for [MarsViewModel] that takes [MarsPhotosRepository] as a dependency
     */
    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val application = (this[APPLICATION_KEY] as CricketApplication)
                val cricketMatchesRepository = application.container.cricketMatchesRepository
                CricketViewModel(cricketMatchesRepository = cricketMatchesRepository)
            }
        }
    }
}
