package com.example.cricketscores.ui

import androidx.compose.runtime.Composable
import androidx.wear.compose.material3.AppScaffold

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.wear.compose.foundation.lazy.TransformingLazyColumn
import androidx.wear.compose.foundation.lazy.rememberTransformingLazyColumnState
import androidx.wear.compose.material3.EdgeButton
import androidx.wear.compose.material3.EdgeButtonSize
import androidx.wear.compose.material3.ScreenScaffold
import androidx.wear.compose.material3.SurfaceTransformation
import androidx.wear.compose.material3.Text
import androidx.wear.compose.material3.lazy.rememberTransformationSpec
import androidx.wear.compose.material3.lazy.transformedHeight
import com.example.cricketscores.R
import com.example.cricketscores.ui.screens.HomeScreen
import com.example.cricketscores.ui.theme.WearAppTheme
import com.example.cricketscores.ui.screens.CricketViewModel
import com.google.android.horologist.compose.layout.ColumnItemType
import com.google.android.horologist.compose.layout.rememberResponsiveColumnPadding
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.wear.compose.material3.MaterialTheme
import androidx.wear.compose.navigation.SwipeDismissableNavHost
import androidx.wear.compose.navigation.composable
import androidx.wear.compose.navigation.rememberSwipeDismissableNavController
import com.example.cricketscores.ui.screens.MatchDetailScreen

@Composable
fun CricketApp() {
    val cricketViewModel: CricketViewModel =
        viewModel(factory = CricketViewModel.Factory)
    WearAppTheme {

        AppScaffold {
            val listState = rememberTransformingLazyColumnState()
            val transformationSpec = rememberTransformationSpec()

            ScreenScaffold(
                scrollState = listState,
                contentPadding = rememberResponsiveColumnPadding(
                    first = ColumnItemType.ListHeader,
                    last = ColumnItemType.Button,
                ),
                /* *************************** Part 11: EdgeButton *************************** */
                // TODO: Add a EdgeButton
                edgeButton = {
                    EdgeButton(
                        onClick =  {
                            if (cricketViewModel.currentMatchDetails != null) {
                                cricketViewModel.clearMatchDetails()
                            } else {
                                cricketViewModel.loadHomeData()
                            }
                        } ,
                        buttonSize = EdgeButtonSize.Small,
                    ) {
                        Text(stringResource(R.string.refresh))
                    }
                },
            ) { contentPadding ->
                val navController = rememberSwipeDismissableNavController()
                SwipeDismissableNavHost(navController = navController, startDestination = "home") {
                    composable("home") {
                        HomeScreen(
                            cricketUiState = cricketViewModel.cricketUiState,
                            retryAction = cricketViewModel::loadHomeData,
                            onOpenDetails = { id -> cricketViewModel.getMatchDetails(id)
                                                navController.navigate("details/$id")},
                            listState = listState,
                            contentPadding = contentPadding,
                            transformationSpec = transformationSpec
                        )
                    }
                    composable("details/{matchId}") { backStackEntry ->
                        val matchId = backStackEntry.arguments?.getString("matchId") ?: "sample"
                        MatchDetailScreen(currentMatchDetails = cricketViewModel.currentMatchDetails)
                    }
                }

                /* *************************** Part 3: ScalingLazyColumn *************************** */
                /*
                 * TransformingLazyColumn applies padding for elements in the list to
                 * make sure no elements are clipped on different screen sizes.
                 * */


                }


                // TODO (End): Create a ScreenScaffold (Wear Version)
            }
            // TODO (End): Create a AppScaffold (Wear Version)
        }
    }
@Composable
fun DetailsScreen(matchId: String) {
    AppScaffold {
        ScreenScaffold(
            scrollState = rememberTransformingLazyColumnState(),
            contentPadding = rememberResponsiveColumnPadding(
                first = ColumnItemType.BodyText,
                last = ColumnItemType.BodyText,
            ),
        ) { contentPadding ->
            TransformingLazyColumn(
                state = rememberTransformingLazyColumnState(),
                contentPadding = contentPadding,
            ) {
                item {
                    Text(
                        text = "Match Details",
                    )
                }
                item {
                    Text(
                        text = "Sample ID: $matchId",
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
                item {
                    Text(
                        text = "IND 178/4 (20.0) vs PAK 160/9 (20.0)",
                    )
                }
                item {
                    Text(
                        text = "Player of the match: Sample Player",
                    )
                }
            }
        }
    }
}
