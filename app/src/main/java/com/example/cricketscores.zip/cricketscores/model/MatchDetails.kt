/*
 * Copyright (C) 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.example.cricketscores.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class MatchDetails(
    val batters: List<Batter> = emptyList(),
    val bowlers: List<Bowler> = emptyList(),
    val currentRunRate: String? = null,
    val keyStats: KeyStats? = null,
    val recent: String? = null,
    val status: String? = null,
    val title: String? = null,
)

@Serializable
data class Batter(
    val balls: String? = null,
    val fours: String? = null,
    val name: String,
    val runs: String? = null,
    val sixes: String? = null,
    val strikeRate: String? = null,
)

@Serializable
data class Bowler(
    val economy: String? = null,
    val maidens: String? = null,
    val name: String,
    val overs: String? = null,
    val runs: String? = null,
    val wickets: String? = null,
)

@Serializable
data class KeyStats(
    val last10Overs: String? = null,
    val lastWicket: String? = null,
    val partnership: String? = null,
    val toss: String? = null,
)


